
For adding custom sprites, use mindustry pallete, along infinity pallete spotted in this branch

Considering im running out of Source moddingn't stuff ideas, at one point i might shift this into source version, and that will probably end up before b-[idk] (since scripting is a thing). Mod may or may not split up, for some reason

People who know scripting, i would like to help me implement a l o t o f s t u f f

 And no, i neither have time nor the nerves to study scripting all day... LIKE SERIOUSLY I NEED HELP

changelog is rendered useless
